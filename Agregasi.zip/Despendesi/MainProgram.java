public class MainProgram {
    public static void main(String[] args) {
        Phone mesin = new Phone();

        mesin.merk = "Snapdragon";

        Phone faiza = new Phone();

        faiza.merk = "Samsung A32";
        faiza.mesin = mesin;
        faiza.powerOn();
        faiza.run();
        faiza.powerOff();
    }
}