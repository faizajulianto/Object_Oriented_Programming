public class Keyboard {
    private String jenis;
    public Keyboard(String jenis) {
        this.jenis = jenis;
    }
    public String getJenis() {
        return this.jenis;
    }
}