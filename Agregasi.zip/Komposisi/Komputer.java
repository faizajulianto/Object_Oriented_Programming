public class Komputer {
    private String merk;
    private String tipe;
    private Mouse mouse;
    private Keyboard keyboard;
    private Cpu cpu;
    public Komputer(String merk, String tipe) {
        this.merk = merk;
        this.tipe = tipe;
    }
    public Komputer(Mouse mouse, Keyboard keyboard, Cpu cpu) {
        this.mouse = mouse;
        this.keyboard = keyboard;
        this.cpu = cpu;
    }
}