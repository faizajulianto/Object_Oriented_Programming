public interface Samsung {

    void powerOn();

    void powerOff();
}