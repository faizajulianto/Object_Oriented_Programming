public class mahasiswa {
    private String nim;
    private String nama;
    public void setNama () {
        this.nama = nama;
    }
    public void setNim (String nim) {
        this.nim = nim;
    }
    public String getNim () {
        return this.nim;
    }
    public String getNama () {
        return this.nama;
    }

    public void setNim() {
    }
}