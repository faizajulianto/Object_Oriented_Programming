public class Cpu {
    private String nama;
    public Cpu(String nama) {
        this.nama = nama;
    }
    public String getNama() {
        return this.nama;
    }
}