public class MainKomputer {
    public static void main(String[] args) {
        // membuat objek komputer
        Komputer komputer = new Komputer("Asus", "A450CC");
    }
}