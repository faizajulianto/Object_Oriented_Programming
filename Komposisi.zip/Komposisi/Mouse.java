public class Mouse {
    private String merk;
    public Mouse(String merk) {
        this.merk = merk;
    }
    public String getMerk() {
        return this.merk;
    }
}